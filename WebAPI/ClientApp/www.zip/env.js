(function (window) {
    window.__env = window.__env || {};

    // API url
    // window.__env.apiUrl = 'https://localhost:44333';
    window.__env.apiUrl = 'https://create-hd.pmbk.vn';

    window.__env.listImage = ['1', '2', '3', '4', '5', '6', '1', '8', '9'];

    // Whether or not to enable debug mode
    // Setting this to false will disable console output
    window.__env.enableDebug = true;
}(this));